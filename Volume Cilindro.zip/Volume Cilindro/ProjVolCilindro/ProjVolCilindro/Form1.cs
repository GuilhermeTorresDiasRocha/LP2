﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Net.Configuration;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ProjVolCilindro
{
    public partial class Form1 : Form
    {
        double raio, altura, resultado;

        public Form1()
        {
            InitializeComponent();
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void txtAltura_Validating(object sender, CancelEventArgs e)
        {
            if(!Double.TryParse(txtAltura.Text, out altura))
            {
                MessageBox.Show("Altura invalida.");
                //e.Cancel = true;
            }
            else if(altura <= 0)
            {
                MessageBox.Show("Altura deve ser maior que zero.");
                //e.Cancel = true;
            }
        }

        private void btnCalc_Click(object sender, EventArgs e)
        {
            if (!Double.TryParse(txtRaio.Text, out raio) || !Double.TryParse(txtAltura.Text, out altura))
            {
                MessageBox.Show("Dados invalidos.");
                txtRaio.Focus();
            }
            else
            {
                resultado = Math.PI * raio * raio * altura;
                txtResult.Text = resultado.ToString("N2");
            }
        }

        private void txtRaio_Validated(object sender, EventArgs e)
        {
            if (!double.TryParse(txtRaio.Text, out raio))
            {
                MessageBox.Show("Dado invalido.");
                //txtRaio.Focus();
            }
            else
            {
                if (raio <= 0)
                {
                    MessageBox.Show("O raio deve ser maior que zero.");
                    //txtRaio.Focus();
                }
            }
        }

        private void btnLimpar_Click(object sender, EventArgs e)
        {
            txtRaio.Text = "";
            txtAltura.Text = String.Empty;
            txtResult.Clear();
        }

        private void btnSair_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void Form1_Validated(object sender, EventArgs e)
        {
           
        }
    }
}