﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Microsoft.VisualBasic;

namespace PVendas02
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btnClear_Click(object sender, EventArgs e)
        {
            lstbxCalc.Items.Clear();
        }

        private void btnVerify_Click(object sender, EventArgs e)
        {
            const int mes = 2;
            const int semana = 4;
            double[,] vendas = new double[mes, semana];
            double auxTotalMes = 0;
            double auxTotalGeral = 0;

            for (int i = 0; i < mes; i++) 
            {
                for (int j = 0; j < semana; j++) 
                {
                    if (!Double.TryParse(Interaction.InputBox($"Entre com o total vendido na {j + 1} semana do {i + 1} mês", "Entrada"), out vendas[i,j]) || vendas[i,j] < 0)
                    {
                        MessageBox.Show("A entrada deve ser um número real não negativo.");
                        j--;
                    }
                }
            }

            for (int i = 0; i < mes; i++)
            {
                for (int j = 0; j < semana; j++)
                {
                    auxTotalMes += vendas[i,j];
                    lstbxCalc.Items.Add($"Total do Mês {i + 1} semana {j + 1}:" + vendas[i,j].ToString("N2") + "\n");
                }
                lstbxCalc.Items.Add($">> Total do Mês {i + 1}: " + auxTotalMes.ToString("N2") + "\n");

                auxTotalGeral += auxTotalMes;
                auxTotalMes = 0;

                lstbxCalc.Items.Add("\n-----------------------------------------------------------\n");
            }
            lstbxCalc.Items.Add(">> Total Geral: " + auxTotalGeral.ToString("N2"));
        }

        private void btnClose_Click(object sender, EventArgs e)
        {
            Close();
        }
    }
}
