﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Classes
{
    public partial class frmMensalista : Form
    {
        public frmMensalista()
        {
            InitializeComponent();
        }

        private void btnInstantiateMensalist_Click(object sender, EventArgs e)
        {
            Mensalista objMensalista = new Mensalista();

            //set
            objMensalista.NomeEmpregado = txtNome.Text;
            objMensalista.Registration = Convert.ToInt32(txtRegist.Text);
            objMensalista.EntryDate = Convert.ToDateTime(txtEntryDate.Text);
            objMensalista.MonthlyIncome = Convert.ToDouble(txtMonthlyIncome.Text);

            //get
            MessageBox.Show($"Nome: {objMensalista.NomeEmpregado}\n" +
                $"Matrícula: {objMensalista.Registration}\n" +
                $"Tempo Trabalhado: {objMensalista.TimeWorked()} dias\n" +
                $"Salário Mensal: {objMensalista.GrossIncome().ToString("N2")}");
        }

        private void btnInstantiateParam_Click(object sender, EventArgs e)
        {

        }
    }
}
