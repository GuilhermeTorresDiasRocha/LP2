﻿namespace Classes
{
    partial class frmMensalista
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lblRegist = new System.Windows.Forms.Label();
            this.lblName = new System.Windows.Forms.Label();
            this.lblMontlyIncome = new System.Windows.Forms.Label();
            this.lblEntryDate = new System.Windows.Forms.Label();
            this.txtRegist = new System.Windows.Forms.TextBox();
            this.txtNome = new System.Windows.Forms.TextBox();
            this.txtMonthlyIncome = new System.Windows.Forms.TextBox();
            this.txtEntryDate = new System.Windows.Forms.TextBox();
            this.btnInstantiateMensalist = new System.Windows.Forms.Button();
            this.btnInstantiateParam = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // lblRegist
            // 
            this.lblRegist.AutoSize = true;
            this.lblRegist.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblRegist.Location = new System.Drawing.Point(38, 29);
            this.lblRegist.Name = "lblRegist";
            this.lblRegist.Size = new System.Drawing.Size(73, 20);
            this.lblRegist.TabIndex = 0;
            this.lblRegist.Text = "Matrícula";
            // 
            // lblName
            // 
            this.lblName.AutoSize = true;
            this.lblName.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblName.Location = new System.Drawing.Point(38, 66);
            this.lblName.Name = "lblName";
            this.lblName.Size = new System.Drawing.Size(51, 20);
            this.lblName.TabIndex = 1;
            this.lblName.Text = "Nome";
            // 
            // lblMontlyIncome
            // 
            this.lblMontlyIncome.AutoSize = true;
            this.lblMontlyIncome.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblMontlyIncome.Location = new System.Drawing.Point(38, 107);
            this.lblMontlyIncome.Name = "lblMontlyIncome";
            this.lblMontlyIncome.Size = new System.Drawing.Size(113, 20);
            this.lblMontlyIncome.TabIndex = 3;
            this.lblMontlyIncome.Text = "Salário Mensal";
            // 
            // lblEntryDate
            // 
            this.lblEntryDate.AutoSize = true;
            this.lblEntryDate.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblEntryDate.Location = new System.Drawing.Point(38, 146);
            this.lblEntryDate.Name = "lblEntryDate";
            this.lblEntryDate.Size = new System.Drawing.Size(127, 20);
            this.lblEntryDate.TabIndex = 2;
            this.lblEntryDate.Text = "Data de Entrada";
            // 
            // txtRegist
            // 
            this.txtRegist.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtRegist.Location = new System.Drawing.Point(167, 26);
            this.txtRegist.Name = "txtRegist";
            this.txtRegist.Size = new System.Drawing.Size(100, 26);
            this.txtRegist.TabIndex = 4;
            // 
            // txtNome
            // 
            this.txtNome.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtNome.Location = new System.Drawing.Point(167, 66);
            this.txtNome.Name = "txtNome";
            this.txtNome.Size = new System.Drawing.Size(205, 26);
            this.txtNome.TabIndex = 5;
            // 
            // txtMonthlyIncome
            // 
            this.txtMonthlyIncome.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtMonthlyIncome.Location = new System.Drawing.Point(167, 107);
            this.txtMonthlyIncome.Name = "txtMonthlyIncome";
            this.txtMonthlyIncome.Size = new System.Drawing.Size(119, 26);
            this.txtMonthlyIncome.TabIndex = 6;
            // 
            // txtEntryDate
            // 
            this.txtEntryDate.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtEntryDate.Location = new System.Drawing.Point(167, 143);
            this.txtEntryDate.Name = "txtEntryDate";
            this.txtEntryDate.Size = new System.Drawing.Size(119, 26);
            this.txtEntryDate.TabIndex = 7;
            // 
            // btnInstantiateMensalist
            // 
            this.btnInstantiateMensalist.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnInstantiateMensalist.Location = new System.Drawing.Point(42, 215);
            this.btnInstantiateMensalist.Name = "btnInstantiateMensalist";
            this.btnInstantiateMensalist.Size = new System.Drawing.Size(126, 61);
            this.btnInstantiateMensalist.TabIndex = 8;
            this.btnInstantiateMensalist.Text = "Instanciar Mensalista";
            this.btnInstantiateMensalist.UseVisualStyleBackColor = true;
            this.btnInstantiateMensalist.Click += new System.EventHandler(this.btnInstantiateMensalist_Click);
            // 
            // btnInstantiateParam
            // 
            this.btnInstantiateParam.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnInstantiateParam.Location = new System.Drawing.Point(191, 215);
            this.btnInstantiateParam.Name = "btnInstantiateParam";
            this.btnInstantiateParam.Size = new System.Drawing.Size(207, 61);
            this.btnInstantiateParam.TabIndex = 9;
            this.btnInstantiateParam.Text = "Instanciar Mensalista Passando Parâmetros";
            this.btnInstantiateParam.UseVisualStyleBackColor = true;
            this.btnInstantiateParam.Click += new System.EventHandler(this.btnInstantiateParam_Click);
            // 
            // frmMensalista
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(438, 306);
            this.Controls.Add(this.btnInstantiateParam);
            this.Controls.Add(this.btnInstantiateMensalist);
            this.Controls.Add(this.txtEntryDate);
            this.Controls.Add(this.txtMonthlyIncome);
            this.Controls.Add(this.txtNome);
            this.Controls.Add(this.txtRegist);
            this.Controls.Add(this.lblMontlyIncome);
            this.Controls.Add(this.lblEntryDate);
            this.Controls.Add(this.lblName);
            this.Controls.Add(this.lblRegist);
            this.Name = "frmMensalista";
            this.Text = "frmMensalista";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lblRegist;
        private System.Windows.Forms.Label lblName;
        private System.Windows.Forms.Label lblMontlyIncome;
        private System.Windows.Forms.Label lblEntryDate;
        private System.Windows.Forms.TextBox txtRegist;
        private System.Windows.Forms.TextBox txtNome;
        private System.Windows.Forms.TextBox txtMonthlyIncome;
        private System.Windows.Forms.TextBox txtEntryDate;
        private System.Windows.Forms.Button btnInstantiateMensalist;
        private System.Windows.Forms.Button btnInstantiateParam;
    }
}