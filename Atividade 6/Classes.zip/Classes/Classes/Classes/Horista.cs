﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Classes
{
    internal class Horista: Empregado //não existe herança múltipla (ie. herdar mais de uma classe)
    {
        //propriedade
        public double HourlyIncome { get; set;}

        //propriedade
        public double NumberHours { get; set;}

        public int AbsenceDays {get; set;}

        public override double GrossIncome()
        {
            return HourlyIncome * NumberHours;
        }

        public override double TimeWorked()
        {
            Double daysWorked;
            DateTime currentDate = DateTime.Today;
            daysWorked = currentDate.Subtract(EntryDate).TotalDays;
            return daysWorked - AbsenceDays;
        }
    }
}
