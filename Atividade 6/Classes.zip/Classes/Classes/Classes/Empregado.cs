﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Classes
{
    abstract internal class Empregado
    {
        //atributos
        private int registration;
        private string nomeEmpregado;
        private DateTime entryDate;

        //propriedades
        public int Registration
        {
            get { return registration; }
            set { registration = value; }
        }

        public string NomeEmpregado
        {
            get { return nomeEmpregado; }
            set { nomeEmpregado = value; }
        }

        public DateTime EntryDate
        {
            get { return entryDate; }
            set { entryDate = value; }
        }

        //método da classe Empregado
        public virtual double TimeWorked()
        {
            Double daysWorked;
            DateTime currentDate = DateTime.Today;
            daysWorked = currentDate.Subtract(entryDate).TotalDays;
            return daysWorked;
        }

        public abstract double GrossIncome();
    }
}