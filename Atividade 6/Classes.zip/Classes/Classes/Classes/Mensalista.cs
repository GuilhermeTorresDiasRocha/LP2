﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Classes
{
    internal class Mensalista: Empregado //herança
    {
        public Double MonthlyIncome
        {
            get;
            set;
        }

        //sobreescrevendo o método grossIncome, que é abstrato na classe mãe
        public override double GrossIncome()
        {
            return MonthlyIncome;
        }
    }
}
