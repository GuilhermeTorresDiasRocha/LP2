﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Pcalc
{
    public partial class Form1 : Form
    {
        double numero1, numero2, result;
        public Form1()
        {
            InitializeComponent();
        }

        private void btnSum_Click(object sender, EventArgs e)
        {
            txtResult.Clear();

            if (!Double.TryParse(txtNum1.Text, out numero1) || !Double.TryParse(txtNum2.Text, out numero2))
            {
                txtNum1.Focus();
            }
            else
            {
                result = numero1 + numero2;
                txtResult.Text = result.ToString();
            }
        }

        private void btnMinus_Click(object sender, EventArgs e)
        {
            txtResult.Clear();

            if (!Double.TryParse(txtNum1.Text, out numero1) || !Double.TryParse(txtNum2.Text, out numero2))
            {
                txtNum1.Focus();
            }
            else
            {
                result = numero1 - numero2;
                txtResult.Text = result.ToString();
            }
        }

        private void btnMult_Click(object sender, EventArgs e)
        {
            txtResult.Clear();

            if (!Double.TryParse(txtNum1.Text, out numero1) || !Double.TryParse(txtNum2.Text, out numero2))
            {
                txtNum1.Focus();
            }
            else
            {
                result = numero1 * numero2;
                txtResult.Text = result.ToString();
            }
        }

        private void btn_Click(object sender, EventArgs e)
        {
            txtResult.Clear();

            if (!Double.TryParse(txtNum1.Text, out numero1) || !Double.TryParse(txtNum2.Text, out numero2) || numero2 == 0)
            {
                txtNum1.Focus();
            }
            else
            {
                if(numero2 == 0)
                {
                    errorProvider2.SetError(txtNum2, "Impossível dividir por zero");
                }
                else
                {
                    result = numero1 / numero2;
                    txtResult.Text = result.ToString();
                }
            }
        }

        private void btnClear_Click(object sender, EventArgs e)
        {
            txtNum1.Clear();
            txtNum2.Clear();
            txtResult.Clear();
        }

        private void btnClose_Click(object sender, EventArgs e)
        {
            if (MessageBox.Show("Sair?", "Calculator", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
                Close();
        }

        private void txtNum2_Validated(object sender, EventArgs e)
        {
            try
            {
                errorProvider2.SetError(txtNum2, "");
                numero2 = Convert.ToDouble(txtNum2.Text);
            }
            catch(Exception) 
            {
                errorProvider2.SetError(txtNum2, "Número 2 inválido");
            }
        }

        private void txtNum1_Validated(object sender, EventArgs e)
        {
            if (!Double.TryParse(txtNum1.Text, out numero1))
            {
                errorProvider1.SetError(txtNum1, "Número 1 inválido");
            }
            else
                errorProvider1.SetError(txtNum1, "");
        }
    }
}
