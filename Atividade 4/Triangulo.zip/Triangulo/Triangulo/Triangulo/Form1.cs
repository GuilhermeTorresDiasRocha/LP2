﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Net.Configuration;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Triangulo
{
    public partial class Triangulerson : Form
    {
        int A, B, C;

        private void btnLimpar_Click(object sender, EventArgs e)
        {
            txtA.Clear();
            txtB.Clear();
            txtC.Clear();
        }

        private void btnSair_Click(object sender, EventArgs e)
        {
            Close();
        }

        public Triangulerson()
        {
            InitializeComponent();
        }

        private void btnCalc_Click(object sender, EventArgs e)
        {
            if(!int.TryParse(txtA.Text, out A))
            {
                errA.SetError(txtA, "O lado deve ser um número inteiro.");
            }
            else if(!int.TryParse(txtB.Text, out B))
            {
                errB.SetError(txtB, "O lado deve ser um número inteiro.");
            }
            else if(!int.TryParse(txtC.Text, out C))
            {
                errC.SetError(txtC, "O lado deve ser um número inteiro.");
            }
            else
            {
                if (Math.Abs(B - C) < A && A < (B + C) && Math.Abs(A - C) < B && B < (A + C) && Math.Abs(A - B) < C && C < (A + B))
                {
                    if(A == B && B == C)
                    {
                        MessageBox.Show("Triângulo Equilátero.");
                    }
                    else if (A == B || A== C || B == C) 
                    {
                        MessageBox.Show("Triângulo Isósceles.");
                    }
                    else 
                    {
                        MessageBox.Show("Triângulo escaleno.");
                    }
                }
                else
                {
                    MessageBox.Show("Estes lados não formam triângulo.");
                }
            }
        }
    }
}