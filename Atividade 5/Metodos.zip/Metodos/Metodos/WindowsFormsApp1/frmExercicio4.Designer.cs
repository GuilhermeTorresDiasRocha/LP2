﻿namespace WindowsFormsApp1
{
    partial class frmExercicio4
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.rchtxtFrase = new System.Windows.Forms.RichTextBox();
            this.btnCountLetters = new System.Windows.Forms.Button();
            this.btnFirstWhiteSpace = new System.Windows.Forms.Button();
            this.btnCountNumber = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // rchtxtFrase
            // 
            this.rchtxtFrase.Location = new System.Drawing.Point(233, 12);
            this.rchtxtFrase.Name = "rchtxtFrase";
            this.rchtxtFrase.Size = new System.Drawing.Size(231, 172);
            this.rchtxtFrase.TabIndex = 0;
            this.rchtxtFrase.Text = "";
            // 
            // btnCountLetters
            // 
            this.btnCountLetters.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnCountLetters.Location = new System.Drawing.Point(569, 291);
            this.btnCountLetters.Name = "btnCountLetters";
            this.btnCountLetters.Size = new System.Drawing.Size(84, 58);
            this.btnCountLetters.TabIndex = 9;
            this.btnCountLetters.Text = "Contar Letras";
            this.btnCountLetters.UseVisualStyleBackColor = true;
            this.btnCountLetters.Click += new System.EventHandler(this.btnCountLetters_Click);
            // 
            // btnFirstWhiteSpace
            // 
            this.btnFirstWhiteSpace.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnFirstWhiteSpace.Location = new System.Drawing.Point(289, 291);
            this.btnFirstWhiteSpace.Name = "btnFirstWhiteSpace";
            this.btnFirstWhiteSpace.Size = new System.Drawing.Size(126, 58);
            this.btnFirstWhiteSpace.TabIndex = 8;
            this.btnFirstWhiteSpace.Text = "1º Espaço em Branco";
            this.btnFirstWhiteSpace.UseVisualStyleBackColor = true;
            this.btnFirstWhiteSpace.Click += new System.EventHandler(this.btnFirstWhiteSpace_Click);
            // 
            // btnCountNumber
            // 
            this.btnCountNumber.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnCountNumber.Location = new System.Drawing.Point(12, 291);
            this.btnCountNumber.Name = "btnCountNumber";
            this.btnCountNumber.Size = new System.Drawing.Size(123, 58);
            this.btnCountNumber.TabIndex = 7;
            this.btnCountNumber.Text = "Contar Números";
            this.btnCountNumber.UseVisualStyleBackColor = true;
            this.btnCountNumber.Click += new System.EventHandler(this.btnCountNumber_Click);
            // 
            // frmExercicio4
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(672, 361);
            this.Controls.Add(this.btnCountLetters);
            this.Controls.Add(this.btnFirstWhiteSpace);
            this.Controls.Add(this.btnCountNumber);
            this.Controls.Add(this.rchtxtFrase);
            this.Name = "frmExercicio4";
            this.Text = "frmExercicio4";
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.RichTextBox rchtxtFrase;
        private System.Windows.Forms.Button btnCountLetters;
        private System.Windows.Forms.Button btnFirstWhiteSpace;
        private System.Windows.Forms.Button btnCountNumber;
    }
}