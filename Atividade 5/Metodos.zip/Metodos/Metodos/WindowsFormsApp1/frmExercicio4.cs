﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp1
{
    public partial class frmExercicio4 : Form
    {
        public frmExercicio4()
        {
            InitializeComponent();
        }

        private void btnCountNumber_Click(object sender, EventArgs e)
        {
            int size = rchtxtFrase.Text.Length;
            int countNum = 0;
            for (int i = 0; i < size; i++)
            {
                if (Char.IsNumber(rchtxtFrase.Text[i]))
                {
                    countNum++;
                }
            }

            MessageBox.Show($"Quantidade de Números: {countNum}");
        }

        private void btnFirstWhiteSpace_Click(object sender, EventArgs e)
        {
            int position = -1;
            for (int i = 0; i < rchtxtFrase.Text.Length; i++)
            {
                if (Char.IsWhiteSpace(rchtxtFrase.Text[i]))
                {
                    position = i;
                    break;
                }
            }

            if(position == -1)
            {
                MessageBox.Show("Não existe espaço em branco");
            }
            else
            {
                MessageBox.Show($"Primeiro espaço em branco na posição: {position + 1}");
            }
        }

        private void btnCountLetters_Click(object sender, EventArgs e)
        {
            int countLetter = 0;

            for (int i = 0; i < rchtxtFrase.Text.Length;i++)
            {
                if (Char.IsLetter(rchtxtFrase.Text[i]))
                {
                    countLetter++;
                }
            }

            MessageBox.Show($"Número de letras: {countLetter}");
        }
    }
}
