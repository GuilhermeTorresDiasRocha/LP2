﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp1
{
    public partial class frmExercicio2 : Form
    {
        public frmExercicio2()
        {
            InitializeComponent();
        }

        private void btnVerifyEqual_Click(object sender, EventArgs e)
        {
            if (String.Compare(txtPalavra1.Text, txtPalavra2.Text, StringComparison.OrdinalIgnoreCase) == 0)
            {
                MessageBox.Show("As palavras são iguais");
            }
            else
            {
                MessageBox.Show("As palavras são diferentes");
            }
        }

        private void btnInsertText_Click(object sender, EventArgs e)
        {
            int halfPalavra2 = txtPalavra2.Text.Length / 2;
            string aux = null;

            for (int i = 0; i < halfPalavra2; i++)
            {
                aux += txtPalavra2.Text[i];
            }
            txtPalavra2.Text = aux + txtPalavra1.Text + txtPalavra2.Text.Substring(halfPalavra2);
        }

        private void btnInsertAsterisk_Click(object sender, EventArgs e)
        {
            int halfPalavra1 = txtPalavra1.Text.Length / 2;
            txtPalavra1.Text = txtPalavra1.Text.Insert(halfPalavra1,"**");
        }

        private void btnClear_Click(object sender, EventArgs e)
        {
            txtPalavra1.Clear();
            txtPalavra2.Clear();
        }
    }
}