﻿namespace WindowsFormsApp1
{
    partial class frmExercicio2
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lblPalavra1 = new System.Windows.Forms.Label();
            this.lblPalavra2 = new System.Windows.Forms.Label();
            this.txtPalavra1 = new System.Windows.Forms.TextBox();
            this.txtPalavra2 = new System.Windows.Forms.TextBox();
            this.btnVerifyEqual = new System.Windows.Forms.Button();
            this.btnInsertText = new System.Windows.Forms.Button();
            this.btnInsertAsterisk = new System.Windows.Forms.Button();
            this.btnClear = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // lblPalavra1
            // 
            this.lblPalavra1.AutoSize = true;
            this.lblPalavra1.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblPalavra1.ForeColor = System.Drawing.Color.White;
            this.lblPalavra1.Location = new System.Drawing.Point(21, 25);
            this.lblPalavra1.Name = "lblPalavra1";
            this.lblPalavra1.Size = new System.Drawing.Size(83, 20);
            this.lblPalavra1.TabIndex = 0;
            this.lblPalavra1.Text = "Palavra 1";
            // 
            // lblPalavra2
            // 
            this.lblPalavra2.AutoSize = true;
            this.lblPalavra2.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblPalavra2.ForeColor = System.Drawing.Color.White;
            this.lblPalavra2.Location = new System.Drawing.Point(21, 100);
            this.lblPalavra2.Name = "lblPalavra2";
            this.lblPalavra2.Size = new System.Drawing.Size(83, 20);
            this.lblPalavra2.TabIndex = 1;
            this.lblPalavra2.Text = "Palavra 2";
            // 
            // txtPalavra1
            // 
            this.txtPalavra1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(28)))), ((int)(((byte)(28)))), ((int)(((byte)(28)))));
            this.txtPalavra1.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtPalavra1.ForeColor = System.Drawing.Color.White;
            this.txtPalavra1.Location = new System.Drawing.Point(110, 22);
            this.txtPalavra1.Name = "txtPalavra1";
            this.txtPalavra1.Size = new System.Drawing.Size(432, 26);
            this.txtPalavra1.TabIndex = 2;
            // 
            // txtPalavra2
            // 
            this.txtPalavra2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(28)))), ((int)(((byte)(28)))), ((int)(((byte)(28)))));
            this.txtPalavra2.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtPalavra2.ForeColor = System.Drawing.Color.White;
            this.txtPalavra2.Location = new System.Drawing.Point(110, 97);
            this.txtPalavra2.Name = "txtPalavra2";
            this.txtPalavra2.Size = new System.Drawing.Size(432, 26);
            this.txtPalavra2.TabIndex = 3;
            // 
            // btnVerifyEqual
            // 
            this.btnVerifyEqual.BackColor = System.Drawing.Color.Indigo;
            this.btnVerifyEqual.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnVerifyEqual.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnVerifyEqual.ForeColor = System.Drawing.Color.White;
            this.btnVerifyEqual.Location = new System.Drawing.Point(25, 151);
            this.btnVerifyEqual.Name = "btnVerifyEqual";
            this.btnVerifyEqual.Size = new System.Drawing.Size(123, 50);
            this.btnVerifyEqual.TabIndex = 4;
            this.btnVerifyEqual.Text = "Verifica iguais";
            this.btnVerifyEqual.UseVisualStyleBackColor = false;
            this.btnVerifyEqual.Click += new System.EventHandler(this.btnVerifyEqual_Click);
            // 
            // btnInsertText
            // 
            this.btnInsertText.BackColor = System.Drawing.Color.Indigo;
            this.btnInsertText.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnInsertText.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnInsertText.ForeColor = System.Drawing.Color.White;
            this.btnInsertText.Location = new System.Drawing.Point(166, 151);
            this.btnInsertText.Name = "btnInsertText";
            this.btnInsertText.Size = new System.Drawing.Size(126, 50);
            this.btnInsertText.TabIndex = 5;
            this.btnInsertText.Text = "Inserir 1º no meio do 2º";
            this.btnInsertText.UseVisualStyleBackColor = false;
            this.btnInsertText.Click += new System.EventHandler(this.btnInsertText_Click);
            // 
            // btnInsertAsterisk
            // 
            this.btnInsertAsterisk.BackColor = System.Drawing.Color.Indigo;
            this.btnInsertAsterisk.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnInsertAsterisk.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnInsertAsterisk.ForeColor = System.Drawing.Color.White;
            this.btnInsertAsterisk.Location = new System.Drawing.Point(310, 151);
            this.btnInsertAsterisk.Name = "btnInsertAsterisk";
            this.btnInsertAsterisk.Size = new System.Drawing.Size(108, 50);
            this.btnInsertAsterisk.TabIndex = 6;
            this.btnInsertAsterisk.Text = "Inserir * no 1º texto";
            this.btnInsertAsterisk.UseVisualStyleBackColor = false;
            this.btnInsertAsterisk.Click += new System.EventHandler(this.btnInsertAsterisk_Click);
            // 
            // btnClear
            // 
            this.btnClear.BackColor = System.Drawing.Color.Indigo;
            this.btnClear.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnClear.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnClear.ForeColor = System.Drawing.Color.White;
            this.btnClear.Location = new System.Drawing.Point(434, 151);
            this.btnClear.Name = "btnClear";
            this.btnClear.Size = new System.Drawing.Size(108, 50);
            this.btnClear.TabIndex = 7;
            this.btnClear.Text = "Limpar";
            this.btnClear.UseVisualStyleBackColor = false;
            this.btnClear.Click += new System.EventHandler(this.btnClear_Click);
            // 
            // frmExercicio2
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(18)))), ((int)(((byte)(18)))), ((int)(((byte)(18)))));
            this.ClientSize = new System.Drawing.Size(554, 220);
            this.Controls.Add(this.btnClear);
            this.Controls.Add(this.btnInsertAsterisk);
            this.Controls.Add(this.btnInsertText);
            this.Controls.Add(this.btnVerifyEqual);
            this.Controls.Add(this.txtPalavra2);
            this.Controls.Add(this.txtPalavra1);
            this.Controls.Add(this.lblPalavra2);
            this.Controls.Add(this.lblPalavra1);
            this.Name = "frmExercicio2";
            this.Text = "frmExercicio2";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lblPalavra1;
        private System.Windows.Forms.Label lblPalavra2;
        private System.Windows.Forms.TextBox txtPalavra1;
        private System.Windows.Forms.TextBox txtPalavra2;
        private System.Windows.Forms.Button btnVerifyEqual;
        private System.Windows.Forms.Button btnInsertText;
        private System.Windows.Forms.Button btnInsertAsterisk;
        private System.Windows.Forms.Button btnClear;
    }
}