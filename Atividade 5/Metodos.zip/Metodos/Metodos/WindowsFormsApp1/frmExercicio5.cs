﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp1
{
    public partial class frmExercicio5 : Form
    { 
        int num1;
        int num2;

        public frmExercicio5()
        {
            InitializeComponent();
        }

        private void btnSortear_Click(object sender, EventArgs e)
        {
            if (!int.TryParse(txtNum1.Text, out num1))
            {
                MessageBox.Show("Digite um número para o valor 1");
            }
            else if (!int.TryParse(txtNum2.Text, out num2))
            {
                MessageBox.Show("Digite um número para o valor 2");
            }
            else if (num1 >= num2)
            {
                MessageBox.Show("O número 1 precisa ser menor que o número 2");
            }
            else
            {
                Random objRdn = new Random();
                int numSorteado = objRdn.Next(num1, num2);
                MessageBox.Show($"O número sorteado é: {numSorteado}");
            }
        }
    }
}
