﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Ptestemetodos
{
    public partial class frmExercicio5 : Form
    {
        public frmExercicio5()
        {
            InitializeComponent();
        }

        private void btnSorteio_Click(object sender, EventArgs e)
        {
            if (numero1 >= numero2)
                MessageBox.Show("O número 1 precisa ser MENOR do que o número 2");
            else
            {
                Random objSorteio = new Random();
                int sorteio = objSorteio.Next(numero1, numero2);
                MessageBox.Show($"O número sorteado foi: {sorteio}");
            }
        }

        int numero1;
        int numero2;
        private void txtNumero1_Validating(object sender, CancelEventArgs e)
        {
            if (!int.TryParse(txtNumero1.Text, out numero1))
            {
                MessageBox.Show("Digite um número correto!");
                e.Cancel = true;
            }
        }

        private void txtNumero2_Validating(object sender, CancelEventArgs e)
        {
            if (!int.TryParse(txtNumero2.Text, out numero2))
            {
                MessageBox.Show("Digite um número correto. Precisa ser maior do que o primeiro número!");
                e.Cancel = true;
            }
        }
    }
}
