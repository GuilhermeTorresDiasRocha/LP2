﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Ptestemetodos
{
    public partial class frmExercicio2 : Form
    {
        //string palavra1;
        //string palavra2;
        public frmExercicio2()
        {
            InitializeComponent();
        }

        private void btnVerificaIguais_Click(object sender, EventArgs e)
        {
            if (string.Compare(txtPalavra1.Text, txtPalavra2.Text) == 0)
                MessageBox.Show("As palavras são IGUAIS!");
            else
                MessageBox.Show("As palavras são DIFERENTES!");
        }

        private void btnInserir1_Click(object sender, EventArgs e)
        {
            int tamanho;
            string parte1;
            string parte2;
            tamanho = txtPalavra2.Text.Length;
            tamanho = tamanho / 2;
            parte1 = txtPalavra2.Text.Substring(0, tamanho);
            parte2 = txtPalavra2.Text.Substring(tamanho);
            txtPalavra2.Text = parte1 + txtPalavra1.Text + parte2;
            //txtPalavra2.Text = "";
            //MessageBox.Show($"{tamanho}");
            //txtPalavra2.Text = txtPalavra2.Text.Insert(tamanho, txtPalavra1.Text);            
        }

        private void btnInserir2_Click(object sender, EventArgs e)
        {
            int tamanho;
            tamanho = txtPalavra1.Text.Length / 2;
            txtPalavra2.Text = txtPalavra1.Text.Insert(tamanho, "**");
        }
    }
}
