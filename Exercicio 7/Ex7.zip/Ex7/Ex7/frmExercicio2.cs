﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Ex7
{
    public partial class frmExercicio2 : Form
    {
        public frmExercicio2()
        {
            InitializeComponent();
        }

        private void btnButao_Click(object sender, EventArgs e)
        {
            int num = 0;
            if (!int.TryParse(txtNum.Text, out num))
            {
                MessageBox.Show("Digite um número válido.");
            }
            else if(num == 0)
            {
                MessageBox.Show("O número deve ser maior que zero.");
            }
            else
            {
                for (int i = 1; i <= num; i++)
                {
                    num += 1 / i;
                }

                MessageBox.Show($"H = {num}");
            }
        }
    }
}
