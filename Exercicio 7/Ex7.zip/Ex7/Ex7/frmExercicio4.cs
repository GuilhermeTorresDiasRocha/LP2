﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Ex7
{
    public partial class frmExercicio4 : Form
    {
        public frmExercicio4()
        {
            InitializeComponent();
        }

        private void btnCalc_Click(object sender, EventArgs e)
        {
            double finalIncome, A;
            double gratification = 0;
            int production;
            A = finalIncome = 0;


            if(!int.TryParse(txtProduction.Text, out production))
            {
                MessageBox.Show("O valor da produção deve ser um número inteiro.");
            }
            else if (!double.TryParse(txtIncome.Text, out A))
            {
                MessageBox.Show("O valor de salário deve ser um número.");
            }
            else if(production < 150 && A >= 7000)
            {
                MessageBox.Show("Valor incorreto para o salário de acordo com a produção.");
            }
            else if(!double.TryParse(txtGratification.Text, out gratification))
            {
                MessageBox.Show("O valor de gratificação deve ser um número.");
            }
            else if(production >= 150)
            {
                finalIncome = (A * 1.25) + gratification;
            }
            else if (production >= 120)
            {
                finalIncome = (A * 1.15) + gratification;
            }
            else if(production >= 100)
            {
                finalIncome = (A * 1.05) + gratification;
            }
            else
            {
                finalIncome = A + gratification;
            }

            MessageBox.Show($"Nome: {txtName.Text}\n" +
                    $"Matrícula: {txtRegistration.Text}\n" +
                    $"Produção: {production}\n" +
                    $"Salário final: R${finalIncome}\n");
        }

        private void btnClear_Click(object sender, EventArgs e)
        {
            txtName.Clear();
            txtRegistration.Clear();
            txtProduction.Clear();
            txtIncome.Clear();
            txtGratification.Clear();
        }
    }
}
