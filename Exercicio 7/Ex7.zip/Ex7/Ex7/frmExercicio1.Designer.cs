﻿namespace Ex7
{
    partial class frmExercicio1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.rchtxtbx = new System.Windows.Forms.RichTextBox();
            this.btnWhiteSpace = new System.Windows.Forms.Button();
            this.btnR = new System.Windows.Forms.Button();
            this.btnPar = new System.Windows.Forms.Button();
            this.txtWhiteSpace = new System.Windows.Forms.TextBox();
            this.txtR = new System.Windows.Forms.TextBox();
            this.txtPar = new System.Windows.Forms.TextBox();
            this.SuspendLayout();
            // 
            // rchtxtbx
            // 
            this.rchtxtbx.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(29)))), ((int)(((byte)(29)))), ((int)(((byte)(29)))));
            this.rchtxtbx.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rchtxtbx.ForeColor = System.Drawing.Color.White;
            this.rchtxtbx.Location = new System.Drawing.Point(12, 12);
            this.rchtxtbx.Name = "rchtxtbx";
            this.rchtxtbx.Size = new System.Drawing.Size(776, 265);
            this.rchtxtbx.TabIndex = 0;
            this.rchtxtbx.Text = "";
            // 
            // btnWhiteSpace
            // 
            this.btnWhiteSpace.BackColor = System.Drawing.Color.Indigo;
            this.btnWhiteSpace.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnWhiteSpace.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnWhiteSpace.Location = new System.Drawing.Point(43, 372);
            this.btnWhiteSpace.Name = "btnWhiteSpace";
            this.btnWhiteSpace.Size = new System.Drawing.Size(174, 66);
            this.btnWhiteSpace.TabIndex = 1;
            this.btnWhiteSpace.Text = "Nº de Espaços em Branco";
            this.btnWhiteSpace.UseVisualStyleBackColor = false;
            this.btnWhiteSpace.Click += new System.EventHandler(this.btnWhiteSpace_Click);
            // 
            // btnR
            // 
            this.btnR.BackColor = System.Drawing.Color.Indigo;
            this.btnR.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnR.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnR.Location = new System.Drawing.Point(324, 372);
            this.btnR.Name = "btnR";
            this.btnR.Size = new System.Drawing.Size(174, 66);
            this.btnR.TabIndex = 2;
            this.btnR.Text = "Nº de Letras R";
            this.btnR.UseVisualStyleBackColor = false;
            this.btnR.Click += new System.EventHandler(this.btnR_Click);
            // 
            // btnPar
            // 
            this.btnPar.BackColor = System.Drawing.Color.Indigo;
            this.btnPar.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnPar.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnPar.Location = new System.Drawing.Point(573, 372);
            this.btnPar.Name = "btnPar";
            this.btnPar.Size = new System.Drawing.Size(174, 66);
            this.btnPar.TabIndex = 3;
            this.btnPar.Text = "Nº Pares de Letras";
            this.btnPar.UseVisualStyleBackColor = false;
            this.btnPar.Click += new System.EventHandler(this.btnPar_Click);
            // 
            // txtWhiteSpace
            // 
            this.txtWhiteSpace.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(29)))), ((int)(((byte)(29)))), ((int)(((byte)(29)))));
            this.txtWhiteSpace.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtWhiteSpace.ForeColor = System.Drawing.Color.White;
            this.txtWhiteSpace.Location = new System.Drawing.Point(43, 331);
            this.txtWhiteSpace.Name = "txtWhiteSpace";
            this.txtWhiteSpace.Size = new System.Drawing.Size(174, 26);
            this.txtWhiteSpace.TabIndex = 4;
            // 
            // txtR
            // 
            this.txtR.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(29)))), ((int)(((byte)(29)))), ((int)(((byte)(29)))));
            this.txtR.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtR.ForeColor = System.Drawing.Color.White;
            this.txtR.Location = new System.Drawing.Point(324, 331);
            this.txtR.Name = "txtR";
            this.txtR.Size = new System.Drawing.Size(174, 26);
            this.txtR.TabIndex = 5;
            // 
            // txtPar
            // 
            this.txtPar.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(29)))), ((int)(((byte)(29)))), ((int)(((byte)(29)))));
            this.txtPar.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtPar.ForeColor = System.Drawing.Color.White;
            this.txtPar.Location = new System.Drawing.Point(573, 331);
            this.txtPar.Name = "txtPar";
            this.txtPar.Size = new System.Drawing.Size(174, 26);
            this.txtPar.TabIndex = 6;
            // 
            // frmExercicio1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(18)))), ((int)(((byte)(18)))), ((int)(((byte)(18)))));
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.txtPar);
            this.Controls.Add(this.txtR);
            this.Controls.Add(this.txtWhiteSpace);
            this.Controls.Add(this.btnPar);
            this.Controls.Add(this.btnR);
            this.Controls.Add(this.btnWhiteSpace);
            this.Controls.Add(this.rchtxtbx);
            this.Name = "frmExercicio1";
            this.Text = "frmExercicio1";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.RichTextBox rchtxtbx;
        private System.Windows.Forms.Button btnWhiteSpace;
        private System.Windows.Forms.Button btnR;
        private System.Windows.Forms.Button btnPar;
        private System.Windows.Forms.TextBox txtWhiteSpace;
        private System.Windows.Forms.TextBox txtR;
        private System.Windows.Forms.TextBox txtPar;
    }
}