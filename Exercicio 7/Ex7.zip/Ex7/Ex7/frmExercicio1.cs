﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Ex7
{
    public partial class frmExercicio1 : Form
    {
        public frmExercicio1()
        {
            InitializeComponent();
        }

        private void btnWhiteSpace_Click(object sender, EventArgs e)
        {
            int numWhiteSpace = 0;

            for(int i = 0; i < rchtxtbx.Text.Length; i++)
            {
                if (Char.IsWhiteSpace(rchtxtbx.Text[i]))
                {
                    numWhiteSpace++;
                }
            }
            txtWhiteSpace.Text = numWhiteSpace.ToString();
        }

        private void btnR_Click(object sender, EventArgs e)
        {
            int numR = 0;

            for (int i = 0; i < rchtxtbx.Text.Length; i++)
            {
                if (rchtxtbx.Text[i] == 'R')
                {
                    numR++;
                }
            }
            txtR.Text = numR.ToString();
        }

        private void btnPar_Click(object sender, EventArgs e)
        {
            int numPar = 0;
            for (int i = 0; i < rchtxtbx.Text.Length - 1; i++)
            {
                if (rchtxtbx.Text[i] == rchtxtbx.Text[i+1])
                {
                    numPar++;
                }
            }
        }
    }
}