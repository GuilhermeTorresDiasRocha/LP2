﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Microsoft.VisualBasic;

namespace Atv8
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btnEx1_Click(object sender, EventArgs e)
        {
            int[] ints = new int[20];
            string aux = "";
            string saida = "";
            for(int i = 0; i < ints.Length; i++)
            {
                aux = Interaction.InputBox($"Digite um número inteiro para a posição {i + 1}:", "Entrada de Dados");

                if(!int.TryParse(aux, out ints[i]))
                {
                    MessageBox.Show("Número inválido.");
                    i--;
                }
                else
                {
                    saida = aux + "\n" + saida;
                }
            }

            //ou
            //Array.Reverse(ints);

            //ou
            //aux = "";
            //foreach(int i in ints)
            //{
            //    aux += i + "\n";
            //}
        }

        private void btnEx2_Click(object sender, EventArgs e)
        {
            List<string> alumni = new List<string>(new string[] {"Ana","André","Débora","Fátima","João","Janete","Otávio","Marcelo","Pedro","Thais"});

            string aux = string.Join(", ", alumni);
            MessageBox.Show($"{aux}");

            alumni.Remove("Otávio");

            aux = string.Join(", ", alumni);
            MessageBox.Show($"{aux}");
        }

        private void btnEx3_Click(object sender, EventArgs e)
        {
            //Constantes pro caso de saída/entrada de alunos, ou no aumento/diminuição da quantidade de notas
            const int qtdAlunos = 20;
            const int qtdNotasPorAluno = 3;

            double[,] grades = new double[qtdAlunos,qtdNotasPorAluno];
            double[] median = new double [qtdAlunos];

            string fiozao = "";

            for (int i = 0; i < grades.GetLength(0); i++)
            {
                for (int j = 0; j < grades.GetLength(1); j++)
                {
                    if (!Double.TryParse(Interaction.InputBox($"Digite a nota {j + 1} do aluno {i + 1}", "Notas"), out grades[i,j]) || grades[i,j] > 10 || grades[i, j] < 0)
                    {
                        MessageBox.Show("A nota do aluno deve ser um número Real entre 0 e 10.");
                        j--;
                    }
                    else
                    {
                        median[i] += grades[i, j] / grades.GetLength(1);
                    }
                }
                fiozao += $"Media do aluno {i + 1}: " + Convert.ToString(median[i]) + "\n\n";
            }

            MessageBox.Show(fiozao);
        }

        private void btnEx4_Click(object sender, EventArgs e)
        {
            if (Application.OpenForms.OfType<frmExercicio4cs>().Count() > 0)
            {
                MessageBox.Show("Form já está aberto.");
                Application.OpenForms["frmExercicio4cs"].BringToFront();
            }
            else
            {
                frmExercicio4cs obj4 = new frmExercicio4cs();
                obj4.Show();
            }
        }

        private void btnEx5_Click(object sender, EventArgs e)
        {
            if(Application.OpenForms.OfType<frmExercicio5>().Count() > 0)
            {
                MessageBox.Show("Form já está aberto.");
                Application.OpenForms["frmExercicio5"].BringToFront();
            }
            else
            {
                frmExercicio5 obj5 = new frmExercicio5();
                obj5.Show();
            }
        }

        private void btnClose_Click(object sender, EventArgs e)
        {
            Close();
        }
    }
}