﻿using Microsoft.VisualBasic;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Atv8
{
    public partial class frmExercicio5 : Form
    {
        public frmExercicio5()
        {
            InitializeComponent();
        }

        private void btnClose_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void btnVerify_Click(object sender, EventArgs e)
        {
            const int numAlumni = 2;
            const int qtdTests = 10;


            char[] answers = {'A', 'B', 'C', 'D', 'E', 'A', 'B', 'C', 'D', 'E' };
            char[,] alumniAnswers = new char[numAlumni, qtdTests];
            string[,] fiozao = new string[numAlumni, qtdTests];

            for (int i = 0; i < numAlumni; i++)
            {
                for (int j = 0; j < qtdTests; j++)
                {
                    alumniAnswers[i, j] = Convert.ToChar(Interaction.InputBox($"Entre com a resposta {j + 1} do aluno {i + 1}: ", "Respostas"));

                    if (!Char.IsLetter(alumniAnswers[i, j]) || Char.ToUpper(alumniAnswers[i, j]) > 'E')
                    {
                        MessageBox.Show("A resposta deve ser uma letra entre A e E.", "Atenção");
                        j--;
                    }
                    else
                    {
                        if (Char.ToUpper(alumniAnswers[i, j]) == answers[j])
                        {
                            fiozao[i,j] = $"O aluno {i + 1} acertou a questão {j + 1}. Era {answers[j]}, Respondeu {alumniAnswers[i, j]}";
                        }
                        else
                        {
                            fiozao[i, j] = $"O aluno {i + 1} errou a questão {j + 1}. Era {answers[j]}, Respondeu {alumniAnswers[i, j]}";
                        }
                    }
                }
            }

            for (int i = 0;i < numAlumni; i++)
            {
                for(int j = 0;j < qtdTests; j++)
                {
                    lstbxRespotas.Items.Add(fiozao[i, j]);
                }
                lstbxRespotas.Items.Add("\n");
            }
        }

        private void btnClear_Click(object sender, EventArgs e)
        {
            lstbxRespotas.Items.Clear();
        }
    }
}
