﻿using Microsoft.VisualBasic;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Atv8
{
    public partial class frmExercicio4cs : Form
    {
        public frmExercicio4cs()
        {
            InitializeComponent();
        }

        private void btnExecute_Click(object sender, EventArgs e)
        {
            //Outra vez, constante pra facilitar possíveis trocas de valores, manutenção, etc.
            //Ninguém vai manter esse código em específico, mas eu acho de bom grado ter o costume :)
            const int numNames = 2;
            string[] names = new string[numNames];
            string[] fiozao = new string[numNames];
            ushort [] numNameLetters = new ushort[numNames];

            lstbxNames.Items.Clear();

            for (int i = 0; i < names.Length; i++)
            {
                names[i] = Interaction.InputBox("Entre com os nomes: ", "Entrada");
                numNameLetters[i] = (ushort) names[i].Replace(" ","").Length;

                fiozao[i] = $"O nome {names[i]}, sem os espaços em branco, tem {numNameLetters[i]} letras";
            }

            for (int i = 0; i < fiozao.Length; i++)
                lstbxNames.Items.Add(fiozao[i]);
        }

        private void btnClose_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void btnClear_Click(object sender, EventArgs e)
        {
            lstbxNames.Items.Clear();
        }
    }
}